function showContent(id) {
    // Ocultar todos los contenidos
    const contents = document.querySelectorAll('.content');
    contents.forEach(content => {
        content.style.display = 'none';
    });

    // Mostrar el contenido correspondiente
    const contentToShow = document.getElementById(id);
    contentToShow.style.display = 'block';
}
